Este Ejercicio requiere que se cree una hoja de datos 
que han sido pasados a XML "Biblioteca.xml" y validados con el archivo XSD "Biblioteca.xsd"
Las consultas se referencian en el archivo "ConsultasBiblioteca.xbook"

El elemento raiz es : "Biblioteca"
El elemento hijo es :"Libros" que se repetira muchas veces pero en este caso 6 
Dentro del elemento "Libros" existen los elementos individuales "libro" con atributo "id" y con sus respectivos hijos
al mismo nivel Título,Autor,Anio,Género,Disponible