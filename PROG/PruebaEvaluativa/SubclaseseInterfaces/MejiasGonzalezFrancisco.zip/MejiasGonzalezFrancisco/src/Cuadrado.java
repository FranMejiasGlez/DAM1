/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mejias Gonzalez Francisco
 */
public class Cuadrado extends Rectangulo {
    //Atributos
    //Constructores
    public Cuadrado(float base,float altura,float lado){
    super(base,altura);
    this.lado=lado;
    }//Fin Constructor
    //Metodos
}//Fin Clase
