package figuras;


/**
 *
 * @author Mejias Gonzalez Francisco
 */
public interface FiguraGeometrica {

    public abstract double area();

    public abstract String getTipoFigura();

    public abstract double perimetro();
}//Fin Interfaz
